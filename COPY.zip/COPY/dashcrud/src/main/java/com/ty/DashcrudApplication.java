package com.ty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DashcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(DashcrudApplication.class, args);
	}

}
