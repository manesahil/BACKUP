package com.ty.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ty.model.uRowmapper;
import com.ty.model.user;

@Repository
public class repositoryimpl implements repository {

	@Autowired
	private JdbcTemplate jdbctemplte;

	public void AddData(user User) {
		String sql = "Insert into user(id,name,phone,address) Values(?,?,?,?)";
		jdbctemplte.update(sql, User.getId(), User.getName(), User.getPhone(), User.getAddress());
	}

	public void UpdateData(String name,Long id) {
		String sql = "UPDATE user SET name=? WHERE id=?";
		jdbctemplte.update(sql, name, id);
	}

	public void DeleteData(Long id) {
		String sql = "DELETE FROM user WHERE id=?";
		jdbctemplte.update(sql, id);
	}

public user ViewData(Long id)
{
String sql="Select * From user Where id=?";
return jdbctemplte.queryForObject(sql, new Object[]{id}, new uRowmapper());

}

}
