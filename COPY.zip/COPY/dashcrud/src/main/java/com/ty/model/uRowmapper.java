package com.ty.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class uRowmapper implements RowMapper<user> {

	@Override
	public user mapRow(ResultSet rs, int rowNum) throws SQLException {
		user User=new user();
		User.setId(rs.getLong("id"));
		User.setName(rs.getString("name"));
		User.setPhone(rs.getLong("phone"));
		User.setAddress(rs.getString("address"));
		return User;
	}
	

}
