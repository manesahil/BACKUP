package com.ty.repository;

import com.ty.model.user;

public interface repository {

	public void AddData(user User);
	public void UpdateData(String name,Long id);
	public void DeleteData(Long id);
	public user ViewData(Long id);

	
}
