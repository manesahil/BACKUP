package com.ty.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ty.Service.service;
import com.ty.model.user;

import org.springframework.web.bind.annotation.PostMapping;



@RestController
@RequestMapping("/userdata")
public class Controller {

	@Autowired
	private service ser;
	
	@PostMapping("/ADD")
	public ResponseEntity<String> AddData(@RequestBody user User) {
		ser.AddData(User);
		
		return ResponseEntity.ok("DATA ADDED SUCCESSFULLY");
	}
	
	@PostMapping("/UPDATE")
	public ResponseEntity<String> UpdateData(@RequestBody user User) {
		ser.UpdateData(User.getName(),User.getId());
		
		return ResponseEntity.ok("DATA UPDATED ADDED SUCCESSFULLY");
	}
	
	@PostMapping("DELETE")
	public ResponseEntity<String> postMethodName(@RequestBody user User) {
		ser.DeleteData(User.getId());
		return ResponseEntity.ok("DATA IS BEEN DELETED");
	}
	
	@PostMapping("/VIEW")
	public ResponseEntity<user> ViewData(@RequestBody user m) {
		user User=ser.ViewData(m.getId());
		return ResponseEntity.ok(User);
	}
	
	
	

	
	
	
	
}
