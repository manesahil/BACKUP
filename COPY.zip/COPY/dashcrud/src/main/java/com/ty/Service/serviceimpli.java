package com.ty.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ty.model.user;
import com.ty.repository.repository;

@Service
public class serviceimpli implements service {

	@Autowired
	private repository resp;

	public void AddData(user User) {
		resp.AddData(User);
	}

	public void UpdateData(String name, Long id) {
		resp.UpdateData(name, id);
	}

	public void DeleteData(Long id) {
		resp.DeleteData(id);
	}

	public user ViewData(Long id) {
		return resp.ViewData(id);
	}

}
