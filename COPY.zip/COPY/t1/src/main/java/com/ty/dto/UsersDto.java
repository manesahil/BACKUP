package com.ty.dto;

public class UsersDto {
	
	

	public Object getUsername() {
		// TODO Auto-generated method stub
		return null;
	}

}
