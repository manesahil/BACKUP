package com.ty.Controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ty.dto.UsersDto;
@RestController
public class Controller {

	 @PostMapping("/login")
		public String login(@RequestBody UsersDto user) {
		
			if ("John".equals(user.getUsername()) && "john123".equals(user.getPassword())) {
				return jwtUtil.generateToken(user.getUsername());
			} else {
				throw new RuntimeException("Invalid credentials");
			}
		}
	
}


