import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
 
public class ExcelToDatabase {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/your_database";
    private static final String USER = "your_username";
    private static final String PASSWORD = "your_password";
    private static final String EXCEL_FILE_PATH = "path/to/your/excel-file.xlsx";
 
    public static void main(String[] args) {
        try (FileInputStream file = new FileInputStream(EXCEL_FILE_PATH);
             Workbook workbook = new XSSFWorkbook(file);
             Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
 
            Sheet sheet = workbook.getSheetAt(0); // First sheet
            int columnCount = sheet.getRow(0).getLastCellNum(); // Number of columns
 
            // Prepare a dynamic SQL insert statement based on the column count
            StringBuilder placeholders = new StringBuilder();
            for (int i = 0; i < columnCount; i++) {
                placeholders.append("?,");
            }
            placeholders.setLength(placeholders.length() - 1); // Remove last comma
            String insertQuery = "INSERT INTO excel_data VALUES (" + placeholders + ")";
 
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                for (Row row : sheet) {
                    if (row.getRowNum() == 0) continue; // Skip header row
 
                    for (int i = 0; i < columnCount; i++) {
                        Cell cell = row.getCell(i, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                        setPreparedStatementValue(preparedStatement, i + 1, cell);
                    }
                    preparedStatement.executeUpdate(); // Insert each row
                }
                System.out.println("Data imported successfully!");
 
            } catch (SQLException e) {
                e.printStackTrace();
            }
 
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }
 
    private static void setPreparedStatementValue(PreparedStatement preparedStatement, int parameterIndex, Cell cell) throws SQLException {
        switch (cell.getCellType()) {
            case STRING:
                preparedStatement.setString(parameterIndex, cell.getStringCellValue());
                break;
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    preparedStatement.setDate(parameterIndex, new java.sql.Date(cell.getDateCellValue().getTime()));
                } else {
                    preparedStatement.setDouble(parameterIndex, cell.getNumericCellValue());
                }
                break;
            case BOOLEAN:
                preparedStatement.setBoolean(parameterIndex, cell.getBooleanCellValue());
                break;
            case BLANK:
                preparedStatement.setNull(parameterIndex, java.sql.Types.NULL);
                break;
            default:
                preparedStatement.setString(parameterIndex, cell.toString());
                break;
        }
    }
}

has context menu
