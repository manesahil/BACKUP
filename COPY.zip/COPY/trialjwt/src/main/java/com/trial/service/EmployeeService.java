package com.trial.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.trial.model.Employee;

@Service
public class EmployeeService {

	private List<Employee> store = new ArrayList<>();

	EmployeeService() {
		store.add(new Employee(UUID.randomUUID().toString(), "sahil", "sahil@gmail.com"));
		store.add(new Employee(UUID.randomUUID().toString(), "yash", "yash@gmail.com"));

	}

	public List<Employee> GetEmployeeList() {

		return store;

	}

}
