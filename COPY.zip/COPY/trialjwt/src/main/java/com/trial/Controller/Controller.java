package com.trial.Controller;

import org.springframework.web.bind.annotation.RestController;

import com.trial.model.Employee;
import com.trial.service.EmployeeService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

@RestController
public class Controller {

	@Autowired
	private EmployeeService employeeService;
	
	
	@GetMapping("/employees")
	public List<Employee> Home() {
		return employeeService.GetEmployeeList();
	}

}
