package com.ty.SpringSecurityTrial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityTrialApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityTrialApplication.class, args);
	}

}
