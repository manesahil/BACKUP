package com.ty.usercrud.Repository;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ty.usercrud.Model.model;
import com.ty.usercrud.Model.userRowmapper;

@Repository
public class repositoryimpl implements respository {

	@Autowired
	private JdbcTemplate jdbctemplate;

	public void insertuser(model m) {
		String q1 = "insert into user(id,name,phone,address)values(?,?,?,?)";
		jdbctemplate.update(q1, m.getId(), m.getName(), m.getPhone(), m.getAddress());
	}

	
	public void updateusername(Long id,String name) {
		String sql = "update user SET name = ? WHERE id = ?";
		jdbctemplate.update(sql, name,id);
	}

	public void deleteuser(Long id) {
		String q1 = "delete from user where id=?";
		jdbctemplate.update(q1,id);
	}
	
	public model readuser(Long id) {
	    String q1 = "select * from user WHERE id=?";
	    return jdbctemplate.queryForObject(q1, new Object[]{id}, new userRowmapper());
	}

}


