package com.ty.usercrud.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ty.usercrud.Model.model;
import com.ty.usercrud.Repository.respository;

@Service
public class serviceimpl implements service{

	@Autowired
	private respository resp;
	
	public void insertuser(model m)
	{
		resp.insertuser(m);
	}
	
	public void updateusername(Long id,String name)
	 {
		resp.updateusername(id,name);
	 }
	 public void deleteuser(Long id)
	  {
		  resp.deleteuser(id);
	  }
	 
	 public model readuser(Long id)
	  {
		  return resp.readuser(id);
	  }
	
}
