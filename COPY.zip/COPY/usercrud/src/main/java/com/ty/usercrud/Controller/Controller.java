package com.ty.usercrud.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ty.usercrud.Model.model;
import com.ty.usercrud.Service.service;

@RestController
@RequestMapping("/crud")
public class Controller {

	@Autowired
	private service ser;

	@PostMapping("/add")
	public ResponseEntity<String> insertuser(@RequestBody model m) {
		try {

			ser.insertuser(m);
			return ResponseEntity.ok("done");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@PostMapping("/update")
	public ResponseEntity<String> updateusername(@RequestBody model userModel) {
		try {

			ser.updateusername(userModel.getId(), userModel.getName());
			return ResponseEntity.ok("Update successful");
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error updating username: " + e.getMessage());
		}
	}

	@PostMapping("/delete")
	public ResponseEntity<String> deleteuser(@RequestBody model m) {
		try {

			ser.deleteuser(m.getId());
			return ResponseEntity.ok("done");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

//	@PostMapping("/view")
//	public ResponseEntity<String> readuser(@RequestBody model m){
//		try
//		{
//			
//			ser.readuser(m.getId());
//			return ResponseEntity.ok("done");
//		}
//		catch (Exception e) {
//			throw new RuntimeException(e);
//		}
//	}

	@PostMapping("/view")
	public ResponseEntity<model> readuser(@RequestBody model m) {
		try {
			model user = ser.readuser(m.getId());
			return ResponseEntity.ok(user);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}

}
