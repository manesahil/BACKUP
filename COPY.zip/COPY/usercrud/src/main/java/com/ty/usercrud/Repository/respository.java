package com.ty.usercrud.Repository;

import com.ty.usercrud.Model.model;

public interface respository {

	  void insertuser(model m);
	  void updateusername(Long id,String name);
	  void deleteuser(Long id);
	  model readuser(Long id);
	
}
