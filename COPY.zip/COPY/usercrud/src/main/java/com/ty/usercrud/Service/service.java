package com.ty.usercrud.Service;

import com.ty.usercrud.Model.model;

public interface service {

	public void deleteuser(Long id);

	public model readuser(Long id);

	public void insertuser(model m);

	public void updateusername(Long id, String name);

}
