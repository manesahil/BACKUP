package com.ty.usercrud.Model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class userRowmapper  implements RowMapper<model>{
	
	@Override
	public model mapRow(ResultSet rs, int rowNum) throws SQLException {
		model m1 =new model();
		m1.setId(rs.getLong("id"));
		m1.setName(rs.getString("name"));
		m1.setPhone(rs.getInt("phone"));
		m1.setAddress(rs.getString("address"));
		return m1;
	}

}
