package com.ty.example.service;

import java.util.List;

import com.ty.example.dto.Userdto;
import com.ty.example.model.User;

public interface service {

	public List<Userdto> Getviewall();

	public Userdto Getviewbyid(Long id);

	public void createEmp(User User);

	public int updateEmp(String email, Long id);

	public void updateEmpAny(Long id, User User);

	public void deleteEmp(Long id);

}
