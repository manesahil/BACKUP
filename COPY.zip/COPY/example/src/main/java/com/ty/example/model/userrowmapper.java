package com.ty.example.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ty.example.dto.Userdto;

public class userrowmapper implements RowMapper<Userdto> {

	@Override
	public Userdto mapRow(ResultSet rs, int rowNum) throws SQLException {

		return new Userdto(rs.getString("firstname"), rs.getString("lastname"), rs.getString("email"),
				rs.getInt("portno"));
	}

}
