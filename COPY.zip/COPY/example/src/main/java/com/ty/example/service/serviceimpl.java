package com.ty.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ty.example.dto.Userdto;
import com.ty.example.model.User;
import com.ty.example.repository.repository;

@Service
public class serviceimpl implements service {

	@Autowired
	private repository repos;

	public List<Userdto> Getviewall() {

		return repos.viewall();
	}

	public Userdto Getviewbyid(Long id) {

		return repos.viewbyid(id);
	}

	public void createEmp(User User) {
		repos.createEmp(User);

	}

	public int updateEmp(String email, Long id)

	{
		return repos.updateEmp(email, id);

	}

	public void updateEmpAny(Long id, User User) {
		repos.updateEmpAny(id, User);
	}

	public void deleteEmp(Long id) {
		repos.deleteEmp(id);

	}

}
