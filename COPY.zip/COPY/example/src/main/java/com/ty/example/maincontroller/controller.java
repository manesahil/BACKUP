package com.ty.example.maincontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.ty.example.dto.Userdto;
import com.ty.example.model.User;
import com.ty.example.service.service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@RestController
@RequestMapping("/crud")
public class controller {

	@Autowired
	private service Service;

	@GetMapping("/viewall")
	public ResponseEntity<List<Userdto>> Getviewall() {
		List<Userdto> users = Service.Getviewall();
		return ResponseEntity.ok(users);
	}

	@GetMapping("/viewbyid/{id}")
	public ResponseEntity<?> Getviewbyid(@PathVariable Long id) {

		Userdto users = Service.Getviewbyid(id);
		if (users == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("the given id :"+id+" not found");
		} else {
			return ResponseEntity.ok(users);

		}

	}

	@PostMapping("/create")
	public ResponseEntity<String> createEmp(@RequestBody User User) {
		Service.createEmp(User);

		return ResponseEntity.ok("New Employee created Successfully");
	}

	@PutMapping("/updatebyid")
	public ResponseEntity<String> updateEmp(@RequestParam String email, Long id) {
		int rowaffected = Service.updateEmp(email, id);
		if (rowaffected > 0) {
			return ResponseEntity.ok("Employee Table updated Successfully");
		} else {
			return ResponseEntity.badRequest().body("the provied id : " + id + " not found");
		}

	}

	@PutMapping("/update/{id}")
	public ResponseEntity<String> updateEmpAny(@PathVariable Long id, @RequestBody User User) {
		Service.updateEmpAny(id, User);

		return ResponseEntity.ok("Employee Table updated Successfully");
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteEmp(@PathVariable Long id) {
		Service.deleteEmp(id);
		return ResponseEntity.ok("Employee is been deleted");
	}

}
