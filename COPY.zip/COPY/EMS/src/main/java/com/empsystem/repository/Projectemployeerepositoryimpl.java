package com.empsystem.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.empsystem.model.Department;
import com.empsystem.model.DepartmentRowMapper;
import com.empsystem.model.EmployeeProjectRowMapper;
import com.empsystem.model.employeeprojects;

@Repository
public class Projectemployeerepositoryimpl implements projectemployeerepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void add(employeeprojects Employeeprojects) {
		String sql = "INSERT INTO employee_projects(employee_id,project_id) VALUES(?,?)";
		jdbcTemplate.update(sql, Employeeprojects.getEmployee_id(), Employeeprojects.getProject_id());
	}

	public List<employeeprojects> Viewbyid(Long id) {
		String sql = "SELECT * FROM employee_projects WHERE employee_id=?";
		return jdbcTemplate.query(sql, new Object[] { id }, new EmployeeProjectRowMapper());
	}

//	public void deletebyid(Long id,Long id1) {
//		String sql = "DELETE FROM employee_projects WHERE employee_id=? AND project_id=?" ;
//		jdbcTemplate.update(sql, id,id1);
//	}

	public void deleteById(Long employeeId, Long projectId) {
		String sql = "DELETE FROM employee_projects WHERE employee_id = ? AND project_id = ?";
		try {
			int rowsAffected = jdbcTemplate.update(sql, employeeId, projectId);
			if (rowsAffected == 0) {
				// Optionally handle case where no records were deleted
				System.out.println("No records found for deletion.");
			}
		} catch (DataAccessException e) {
			// Handle the exception (e.g., log it)
			System.err.println("Error during deletion: " + e.getMessage());
		}
	}

	public List<employeeprojects> viewall() {
		String sql = "SELECT * FROM employee_projects";
		return jdbcTemplate.query(sql, new EmployeeProjectRowMapper());
	}
//
//	public void update(Long id, employeeprojects employeeprojects) {
//		String sql = "UPDATE departments SET name=?,description=? WHERE department_id=? ";
//		jdbcTemplate.update(sql, employeeprojects.getEmployee_id(), employeeprojects.getProject_id(), id);
//	}

	

}
