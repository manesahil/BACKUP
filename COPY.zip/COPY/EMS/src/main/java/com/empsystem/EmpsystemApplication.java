package com.empsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpsystemApplication.class, args);
	}

}
