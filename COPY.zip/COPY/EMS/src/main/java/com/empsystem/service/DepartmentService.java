package com.empsystem.service;

import java.util.List;

import com.empsystem.model.Department;

public interface DepartmentService {

	public void deptadd(Department department);

	public Department Viewbyid(Long id);

	public void deletebyid(Long id);
	
	public List<Department> viewall();
	
	public void update(Long id,Department department);
}
