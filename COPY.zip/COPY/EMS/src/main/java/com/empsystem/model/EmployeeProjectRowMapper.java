package com.empsystem.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class EmployeeProjectRowMapper implements RowMapper<employeeprojects>{

	@Override
	public employeeprojects mapRow(ResultSet rs, int rowNum) throws SQLException {
	
		employeeprojects Employee_projects = new employeeprojects();
		Employee_projects.setEmployee_id(rs.getLong("employee_id"));
		Employee_projects.setProject_id(rs.getLong("project_id"));
		return Employee_projects;
	}

}
