package com.empsystem.service;

import java.util.List;

import com.empsystem.model.employeeprojects;

public interface ProjectemployeeService {
	
	public void add(employeeprojects Employeeprojects);
	
	public List<employeeprojects> Viewbyid(Long id);

	public void deleteById(Long employeeId, Long projectId);
	
	public List<employeeprojects> viewall();

}
