package com.empsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.empsystem.model.employeeprojects;
import com.empsystem.service.ProjectemployeeService;

@RestController
@RequestMapping("/employeeproject")
public class employeeprojectsController {

	@Autowired
	private ProjectemployeeService projectemployeeService;

	@PostMapping("/add")
	public ResponseEntity<String> add(@RequestBody employeeprojects employeeprojects) {
		projectemployeeService.add(employeeprojects);

		return ResponseEntity.ok("Data inserted");
	}

	@PostMapping("/viewbyid/{id}")
	public ResponseEntity<List<employeeprojects>> Viewbyid(@PathVariable Long id) {
		projectemployeeService.Viewbyid(id);

		return ResponseEntity.ok(projectemployeeService.Viewbyid(id));
	}

	@DeleteMapping("/delete/{employeeId}/{projectId}")
	public ResponseEntity<String> deletebyid(@PathVariable Long employeeId, @PathVariable Long projectId) {
		projectemployeeService.deleteById(employeeId, projectId);

		return ResponseEntity.ok("data deleted");
	}
	
	
	@PostMapping("/viewall")
	public ResponseEntity<List<employeeprojects>> viewall() {
		projectemployeeService.viewall();

		return ResponseEntity.ok(projectemployeeService.viewall());
	}
	
	
}
