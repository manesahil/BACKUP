package com.empsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.empsystem.dto.EmployeeRequest;
import com.empsystem.model.Employee;
import com.empsystem.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class employeeController {
	@Autowired
	private EmployeeService employeeService;

	@PostMapping("/add")
	public ResponseEntity<String> insertemp(@RequestBody EmployeeRequest EmployeeRequest) {

		employeeService.insertemp(EmployeeRequest);
		return ResponseEntity.ok("ok");
	}

	@PostMapping("/viewbyid/{id}")
	public ResponseEntity<EmployeeRequest> viewbyid(@PathVariable Long id) {
		employeeService.viewbyid(id);

		return ResponseEntity.ok(employeeService.viewbyid(id));
	}

	@PostMapping("/viewall")
	public ResponseEntity<List<EmployeeRequest>> viewall() {
		employeeService.viewall();

		return ResponseEntity.ok(employeeService.viewall());
	}

	@DeleteMapping("/deletebyid/{id}")
	public ResponseEntity<String> deletebyid(@PathVariable Long id) {
		employeeService.Deletebyid(id);
		return ResponseEntity.ok("Employee table deleted");
	}

	@PostMapping("/update")
	public ResponseEntity<ResponseEntity<EmployeeRequest>> postMethodName(@RequestParam Long id, Long departmentId) {
		employeeService.UpdateDeptno(departmentId, id);

		return ResponseEntity.ok(viewbyid(id));
	}

	@PostMapping("sort/{sortBy}")
	public ResponseEntity<List<EmployeeRequest>> findSorted(@PathVariable String sortBy) {
		employeeService.findSorted(sortBy);
		return ResponseEntity.ok(employeeService.findSorted(sortBy));
	}

	@PostMapping("/Paginated/{page}/{size}")
	public ResponseEntity<List<EmployeeRequest>> findPaginated(@PathVariable int page, @PathVariable int size) {
		employeeService.findPaginated(page, size);

		return ResponseEntity.ok(employeeService.findPaginated(page, size));
	}
	
	@PostMapping("/sortbydept/{departmentId}")
	public ResponseEntity<List<EmployeeRequest>> sortbydept(@PathVariable Long departmentId) {
		employeeService.sortbydept(departmentId);
		
		return ResponseEntity.ok(employeeService.sortbydept(departmentId));
	}
	

}
